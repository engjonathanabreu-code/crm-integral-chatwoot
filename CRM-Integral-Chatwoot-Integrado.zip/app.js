import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";

const CONFIG = window.CRM_CONFIG || {};
const CLIENT_STATUSES = ["Novo", "Contato feito", "Proposta enviada", "Negociação", "Fechado", "Perdido"];
const TICKET_SECTORS = ["Atendimento", "Comercial", "Financeiro", "Projetos", "Topografia", "Pós-Protocolo"];
const TICKET_STATUSES = ["Aberto", "Em andamento", "Resolvido"];
const MARKETING_FASE_COLORS = { 1: "var(--fase1)", 2: "var(--fase2)", 3: "var(--fase3)", 4: "var(--fase4)", 5: "var(--fase5)" };
const PROGRESS_STATUSES = ["Topografia", "Projeto", "Protocolado", "Correções para Prefeitura", "Registro de Imóveis", "Concluído", "Outros"];
const LIST_PAGE_SIZE = 30;

const state = {
  user: null,
  profile: null,
  profiles: [],
  clients: [],
  tickets: [],
  tasks: [],
  history: [],
  interactions: [],
  marketingEtapas: [],
  marketingProjects: [],
  marketingProgress: [],
  projects: [],
  projectProgress: [],
  projectSchemaReady: false,
  projectsDrill: { municipio: null, projetoId: null },
  progressDrill: { municipio: null, projetoId: null },
  currentView: "dashboard",
  selectedClientId: null,
  selectedMarketingProjectId: null,
  ticketsVisible: LIST_PAGE_SIZE,
  tasksVisible: LIST_PAGE_SIZE,
};

let supabase = null;

const $ = (id) => document.getElementById(id);
const isConfigured = () =>
  CONFIG.supabaseUrl &&
  CONFIG.supabaseAnonKey &&
  !CONFIG.supabaseUrl.includes("COLE_AQUI") &&
  !CONFIG.supabaseAnonKey.includes("COLE_AQUI");
const isAdmin = () => state.profile?.perfil === "admin";
const isMarketingTeam = () => isAdmin() || state.profile?.perfil === "marketing";

function escapeHtml(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function money(value) {
  return Number(value || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function formatDate(value) {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "-";
  return date.toLocaleDateString("pt-BR");
}

function formatDateTime(value) {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "-";
  return date.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function showToast(message, type = "success") {
  const toast = $("toast");
  toast.textContent = message;
  toast.className = `toast ${type}`;
  setTimeout(() => toast.classList.add("hidden"), 3500);
}

function setSync(status, message) {
  const element = $("syncStatus");
  element.className = `sync-status ${status || ""}`;
  element.textContent = message;
}

function statusBadge(status) {
  const cls = status === "Fechado" || status === "Resolvido" ? "closed" : status === "Perdido" ? "lost" : status === "Aberto" ? "open" : "";
  return `<span class="badge ${cls}">${escapeHtml(status || "-")}</span>`;
}

function profileName(id) {
  const profile = state.profiles.find((item) => item.id === id) || (id === state.user?.id ? state.profile : null);
  return profile?.apelido || profile?.nome || "Usuário";
}

function normalizeNickname(value) {
  return String(value || "").trim().toLowerCase();
}

function isValidNickname(value) {
  return /^[a-z0-9._-]{3,30}$/.test(normalizeNickname(value));
}

function clientName(id) {
  return state.clients.find((client) => client.id === id)?.nome || "Cliente removido";
}

function clientMunicipio(id) {
  return state.clients.find((client) => client.id === id)?.municipio || "Sem município informado";
}

function clientNucleo(id) {
  return state.clients.find((client) => client.id === id)?.nucleo || "Sem NUI informado";
}


function projectById(id) {
  return state.projects.find((project) => project.id === id);
}

function municipioKeyOf(projectLike) {
  return `${(projectLike.cidade || "").trim().toLowerCase()}|${(projectLike.estado || "").trim().toUpperCase()}`;
}

function groupProjectsByMunicipio(projects) {
  const map = new Map();
  projects.forEach((project) => {
    const key = municipioKeyOf(project);
    if (!map.has(key)) map.set(key, { key, cidade: project.cidade, estado: project.estado, projects: [] });
    map.get(key).projects.push(project);
  });
  return [...map.values()].sort((a, b) =>
    `${a.cidade}/${a.estado}`.localeCompare(`${b.cidade}/${b.estado}`, "pt-BR")
  );
}

function projectLabel(project) {
  if (!project) return "Projeto não informado";
  return `${project.nome} — ${project.cidade}/${project.estado}`;
}

function clientProject(clientOrId) {
  const client = typeof clientOrId === "string" ? state.clients.find((item) => item.id === clientOrId) : clientOrId;
  return projectById(client?.projeto_id);
}

function isMissingRelationError(error) {
  return error && (error.code === "42P01" || error.code === "42703" || /does not exist|Could not find.*schema cache/i.test(error.message || ""));
}

async function loadOptionalProjectData() {
  const [projectsResult, progressResult] = await Promise.all([
    supabase.from("projetos").select("*").order("cidade").order("nome"),
    supabase.from("andamentos").select("*").order("data_atualizacao", { ascending: false }).order("created_at", { ascending: false }),
  ]);
  if (isMissingRelationError(projectsResult.error) || isMissingRelationError(progressResult.error)) {
    state.projects = [];
    state.projectProgress = [];
    state.projectSchemaReady = false;
    return;
  }
  if (projectsResult.error) throw projectsResult.error;
  if (progressResult.error) throw progressResult.error;
  state.projects = projectsResult.data || [];
  state.projectProgress = progressResult.data || [];
  state.projectSchemaReady = true;
}

function showOnly(screenId) {
  ["setupScreen", "loginScreen", "appShell"].forEach((id) => $(id).classList.add("hidden"));
  $(screenId).classList.remove("hidden");
}

async function bootstrap() {
  bindEvents();
  fillStaticOptions();

  if (!isConfigured()) {
    showOnly("setupScreen");
    return;
  }

  supabase = createClient(CONFIG.supabaseUrl, CONFIG.supabaseAnonKey, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
  });

  const { data, error } = await supabase.auth.getSession();
  if (error) console.error(error);

  if (data?.session?.user) {
    await startAuthenticated(data.session.user);
  } else {
    showOnly("loginScreen");
  }

  supabase.auth.onAuthStateChange(async (event, session) => {
    if (event === "SIGNED_OUT" || !session?.user) {
      resetState();
      showOnly("loginScreen");
    }
  });
}

function resetState() {
  Object.assign(state, {
    user: null,
    profile: null,
    profiles: [],
    clients: [],
    tickets: [],
    tasks: [],
    history: [],
  interactions: [],
    marketingEtapas: [],
    marketingProjects: [],
    marketingProgress: [],
    projects: [],
    projectProgress: [],
    projectSchemaReady: false,
    projectsDrill: { municipio: null, projetoId: null },
    progressDrill: { municipio: null, projetoId: null },
    selectedClientId: null,
    selectedMarketingProjectId: null,
  });
}

async function startAuthenticated(user) {
  state.user = user;
  setSync("loading", "Carregando...");

  const { data: profile, error } = await supabase
    .from("profiles")
    .select("id,nome,perfil,ativo,created_at")
    .eq("id", user.id)
    .single();

  if (error || !profile) {
    console.error(error);
    await supabase.auth.signOut();
    $("loginMessage").textContent = "Seu perfil não foi encontrado. Execute o SQL de instalação ou fale com o administrador.";
    return;
  }

  if (!profile.ativo) {
    await supabase.auth.signOut();
    $("loginMessage").textContent = "Este usuário está desativado.";
    return;
  }

  state.profile = profile;
  showOnly("appShell");
  applyRoleUI();
  await loadData();
  setView("dashboard");
}

function applyRoleUI() {
  $("sidebarUserName").textContent = state.profile.nome || state.user.email;
  $("sidebarUserRole").textContent = isAdmin() ? "Administrador — acesso total" : "Usuário — dados próprios";
  document.querySelectorAll(".admin-only").forEach((element) => element.classList.toggle("hidden", !isAdmin()));
  document.querySelectorAll(".marketing-only").forEach((element) => element.classList.toggle("hidden", !isMarketingTeam()));
}

async function loadData() {
  setSync("loading", "Atualizando...");
  try {
    const marketingQueries = isMarketingTeam()
      ? [
          supabase.from("marketing_etapas").select("*").order("ordem"),
          supabase.from("marketing_projetos").select("*").order("municipio"),
          supabase.from("marketing_progresso").select("*"),
        ]
      : [Promise.resolve({ data: [] }), Promise.resolve({ data: [] }), Promise.resolve({ data: [] })];

    const [profilesResult, clientsResult, ticketsResult, tasksResult, historyResult, interactionsResult, etapasResult, projectsResult, progressResult] = await Promise.all([
      supabase.from("profiles").select("id,nome,apelido,perfil,ativo,created_at").order("apelido", { ascending: true, nullsFirst: false }).order("nome"),
      supabase.from("clientes").select("*").order("created_at", { ascending: false }),
      supabase.from("atendimentos").select("*").order("created_at", { ascending: false }),
      supabase.from("tarefas").select("*").order("data", { ascending: true }),
      supabase.from("historico").select("*").order("created_at", { ascending: false }),
      supabase.from("interacoes").select("*").order("created_at", { ascending: false }),
      ...marketingQueries,
    ]);

    const failures = [profilesResult, clientsResult, ticketsResult, tasksResult, historyResult, interactionsResult, etapasResult, projectsResult, progressResult].filter((result) => result.error);
    if (failures.length) throw failures[0].error;

    state.profiles = profilesResult.data || [];
    state.clients = clientsResult.data || [];
    state.tickets = ticketsResult.data || [];
    state.tasks = tasksResult.data || [];
    state.history = historyResult.data || [];
    state.interactions = interactionsResult.data || [];
    state.marketingEtapas = etapasResult.data || [];
    state.marketingProjects = projectsResult.data || [];
    state.marketingProgress = progressResult.data || [];

    await loadOptionalProjectData();

    renderAll();
    setSync("", "Sincronizado");
  } catch (error) {
    console.error(error);
    setSync("error", "Erro de sincronização");
    showToast(`Erro ao carregar dados: ${error.message}`, "error");
  }
}

function fillStaticOptions() {
  $("clientStatus").innerHTML = CLIENT_STATUSES.map((status) => `<option>${status}</option>`).join("");
  $("clientStatusFilter").innerHTML = `<option value="">Todos os status</option>${CLIENT_STATUSES.map((status) => `<option>${status}</option>`).join("")}`;
  $("ticketSector").innerHTML = TICKET_SECTORS.map((sector) => `<option>${sector}</option>`).join("");
  $("ticketSectorFilter").innerHTML = `<option value="">Todos os setores</option>${TICKET_SECTORS.map((sector) => `<option>${sector}</option>`).join("")}`;
  $("ticketStatus").innerHTML = TICKET_STATUSES.map((status) => `<option>${status}</option>`).join("");
  $("ticketStatusFilter").innerHTML = `<option value="">Todos os status</option>${TICKET_STATUSES.map((status) => `<option>${status}</option>`).join("")}`;
  $("ticketStandaloneSector").innerHTML = TICKET_SECTORS.map((sector) => `<option>${sector}</option>`).join("");
  $("ticketStandaloneStatus").innerHTML = TICKET_STATUSES.map((status) => `<option>${status}</option>`).join("");
  $("taskDueDate").value = today();
}

function renderAll() {
  renderOwnerOptions();
  renderDashboard();
  renderClients();
  renderPipeline();
  renderTickets();
  renderTasks();
  renderUsers();
  renderProjects();
  renderProjectProgress();
  renderMarketingProjects();
  if (state.selectedClientId && $("clientDetailDialog").open) renderClientDetail(state.selectedClientId);
  if (state.selectedMarketingProjectId && $("marketingJourneyDialog").open) renderMarketingJourney(state.selectedMarketingProjectId);
}

function renderOwnerOptions() {
  const activeProfiles = state.profiles.filter((profile) => profile.ativo);
  const options = activeProfiles.map((profile) => `<option value="${profile.id}">${escapeHtml(profile.nome)}${profile.perfil === "admin" ? " (Admin)" : ""}</option>`).join("");
  $("clientOwner").innerHTML = options;
  $("taskAssignee").innerHTML = options;
  $("taskStandaloneAssignee").innerHTML = options;

  const filterOptions = `<option value="">Todos os responsáveis</option>${options}`;
  $("clientOwnerFilter").innerHTML = filterOptions;
  $("pipelineOwnerFilter").innerHTML = filterOptions;

  const projectOptions = state.projects
    .filter((project) => project.ativo)
    .sort((a, b) => `${a.estado}-${a.cidade}-${a.nome}`.localeCompare(`${b.estado}-${b.cidade}-${b.nome}`, "pt-BR"))
    .map((project) => `<option value="${project.id}">${escapeHtml(projectLabel(project))}</option>`).join("");
  if ($("clientProject")) $("clientProject").innerHTML = `<option value="">Sem projeto vinculado (cadastro legado)</option>${projectOptions}`;
  if ($("progressProject")) $("progressProject").innerHTML = `<option value="">Selecione um projeto</option>${projectOptions}`;

  if ($("marketingProjectSelect")) $("marketingProjectSelect").innerHTML = `<option value="">Selecione um projeto</option>${projectOptions}`;
}

function renderDashboard() {
  $("metricClients").textContent = state.clients.length;
  $("metricNegotiation").textContent = state.clients.filter((client) => client.status === "Negociação").length;
  $("metricOpenTickets").textContent = state.tickets.filter((ticket) => ticket.status !== "Resolvido").length;
  $("metricPendingTasks").textContent = state.tasks.filter((task) => !task.concluida).length;

  const activePipeline = state.clients.filter((client) => !["Fechado", "Perdido"].includes(client.status));
  const showMoney = isAdmin();
  $("pipelineValue").textContent = showMoney ? money(activePipeline.reduce((sum, client) => sum + Number(client.valor_estimado || 0), 0)) : "Restrito";
  $("pipelineValue").classList.toggle("kpi-restricted", !showMoney);
  $("pipelineValue").title = showMoney ? "" : "Valores do funil visíveis apenas para administradores.";

  $("dashboardPipeline").innerHTML = CLIENT_STATUSES.map((status) => {
    const list = state.clients.filter((client) => client.status === status);
    const total = list.reduce((sum, client) => sum + Number(client.valor_estimado || 0), 0);
    const valueHtml = showMoney ? `<strong>${money(total)}</strong>` : `<strong class="kpi-restricted">Restrito</strong>`;
    return `<div class="summary-row"><div><strong>${escapeHtml(status)}</strong><small>${list.length} cliente(s)</small></div>${valueHtml}</div>`;
  }).join("");

  $("dashboardService").innerHTML = TICKET_SECTORS.map((sector) => {
    const list = state.tickets.filter((ticket) => ticket.setor === sector);
    const open = list.filter((ticket) => ticket.status !== "Resolvido").length;
    return `<div class="summary-row"><div><strong>${escapeHtml(sector)}</strong><small>${list.length} registro(s)</small></div><strong>${open} aberto(s)</strong></div>`;
  }).join("");

  const pendingTasks = state.tasks.filter((task) => !task.concluida).sort((a, b) => String(a.data || "").localeCompare(String(b.data || ""))).slice(0, 7);
  $("dashboardTasks").innerHTML = pendingTasks.length ? pendingTasks.map((task) => `
    <div class="record-row">
      <h4>${escapeHtml(task.titulo)}</h4>
      <p class="muted">${escapeHtml(clientName(task.cliente_id))} • ${formatDate(task.data)} • ${escapeHtml(task.prioridade)}</p>
    </div>`).join("") : emptyState("Nenhuma tarefa pendente.");

  const recent = buildRecentActivity().slice(0, 7);
  $("dashboardHistory").innerHTML = recent.length ? recent.map((item) => `
    <div class="record-row">
      <h4>${escapeHtml(item.title)}</h4>
      <p class="muted">${escapeHtml(item.client)} • ${formatDateTime(item.date)}</p>
    </div>`).join("") : emptyState("Nenhuma interação registrada.");
}

function buildRecentActivity(clientId = null) {
  const history = state.history
    .filter((item) => !clientId || item.cliente_id === clientId)
    .map((item) => ({ date: item.created_at, title: item.tipo, text: item.descricao, client: clientName(item.cliente_id), author: profileName(item.created_by), kind: "history" }));

  const tickets = state.tickets
    .filter((item) => !clientId || item.cliente_id === clientId)
    .map((item) => ({ date: item.created_at, title: `Atendimento — ${item.assunto}`, text: `${item.setor} • ${item.status}${item.observacao ? ` • ${item.observacao}` : ""}`, client: clientName(item.cliente_id), author: profileName(item.created_by), kind: "ticket" }));

  const tasks = state.tasks
    .filter((item) => !clientId || item.cliente_id === clientId)
    .map((item) => ({ date: item.updated_at || item.created_at, title: `Tarefa — ${item.titulo}`, text: `${item.concluida ? "Concluída" : "Pendente"} • prazo ${formatDate(item.data)} • ${item.prioridade}`, client: clientName(item.cliente_id), author: profileName(item.created_by), kind: "task" }));

  const interactions = state.interactions
    .filter((item) => !clientId || item.cliente_id === clientId)
    .map((item) => ({
      date: item.created_at,
      title: `${item.autor_tipo || "Sistema"}${item.setor ? ` — ${item.setor}` : ""}`,
      text: item.conteudo || item.evento || "Interação registrada",
      client: clientName(item.cliente_id),
      author: item.autor_nome || item.autor_tipo || "Sistema",
      kind: "interaction",
    }));

  return [...history, ...tickets, ...tasks, ...interactions].sort((a, b) => new Date(b.date) - new Date(a.date));
}

function renderClients() {
  const search = $("clientSearch").value.trim().toLowerCase();
  const municipality = $("municipalityFilter").value;
  const nucleus = $("nucleusFilter").value;
  const status = $("clientStatusFilter").value;
  const owner = $("clientOwnerFilter").value;

  const municipalities = [...new Set(state.clients.map((client) => client.municipio || "Sem município informado"))].sort((a, b) => a.localeCompare(b, "pt-BR"));
  $("municipalityFilter").innerHTML = `<option value="">Todos os municípios</option>${municipalities.map((item) => `<option value="${escapeHtml(item)}">${escapeHtml(item)}</option>`).join("")}`;
  $("municipalityFilter").value = municipality;

  const nucleusPool = state.clients.filter((client) => !municipality || (client.municipio || "Sem município informado") === municipality);
  const nucleusOptions = [...new Set(nucleusPool.map((client) => client.nucleo || "Sem NUI informado"))].sort((a, b) => a.localeCompare(b, "pt-BR"));
  $("nucleusFilter").innerHTML = `<option value="">Todos os NUIs</option>${nucleusOptions.map((item) => `<option value="${escapeHtml(item)}">${escapeHtml(item)}</option>`).join("")}`;
  $("nucleusFilter").value = nucleusOptions.includes(nucleus) ? nucleus : "";

  const filtered = state.clients.filter((client) => {
    const haystack = [client.nome, client.municipio, client.nucleo, client.remessa, client.telefone, client.email, client.responsavel].join(" ").toLowerCase();
    return (!search || haystack.includes(search)) &&
      (!municipality || (client.municipio || "Sem município informado") === municipality) &&
      (!nucleus || (client.nucleo || "Sem NUI informado") === nucleus) &&
      (!status || client.status === status) &&
      (!owner || client.owner_id === owner);
  });

  const municipalityGroups = filtered.reduce((acc, client) => {
    const city = client.municipio || "Sem município informado";
    (acc[city] ||= []).push(client);
    return acc;
  }, {});
  const cityCount = Object.keys(municipalityGroups).length;

  $("clientResultCount").textContent = filtered.length
    ? `${filtered.length} cliente(s) encontrado(s) em ${cityCount} município(s).`
    : "";

  if (!filtered.length) {
    $("clientsByMunicipality").innerHTML = emptyState("Nenhum cliente encontrado com esses filtros.");
    return;
  }

  const isFiltering = Boolean(search || municipality || nucleus || status || owner);
  const autoExpand = isFiltering || filtered.length <= 60;

  $("clientsByMunicipality").innerHTML = Object.keys(municipalityGroups).sort((a, b) => a.localeCompare(b, "pt-BR")).map((city) => {
    const clientsInCity = municipalityGroups[city];
    const nucleusGroups = clientsInCity.reduce((acc, client) => {
      const nuc = client.nucleo || "Sem NUI informado";
      (acc[nuc] ||= []).push(client);
      return acc;
    }, {});
    const nucleusHtml = Object.keys(nucleusGroups).sort((a, b) => a.localeCompare(b, "pt-BR")).map((nuc) => `
      <details class="nucleus-group" ${autoExpand ? "open" : ""}>
        <summary>${escapeHtml(nuc)} <span>${nucleusGroups[nuc].length}</span></summary>
        <div class="client-row-list">${nucleusGroups[nuc].map(clientRow).join("")}</div>
      </details>`).join("");
    return `<details class="municipality-group" ${autoExpand ? "open" : ""}>
      <summary><span class="municipality-group-title">${escapeHtml(city)}<small>${clientsInCity.length} cliente(s) • ${Object.keys(nucleusGroups).length} NUI(s)</small></span></summary>
      <div class="nucleus-groups">${nucleusHtml}</div>
    </details>`;
  }).join("");
}

function clientRow(client) {
  return `<button class="client-row" data-open-client="${client.id}">
    <div><strong>${escapeHtml(client.nome)}</strong><span>${escapeHtml(client.telefone || client.email || "Sem contato")}</span></div>
    <div>${statusBadge(client.status)}</div>
    <div><strong>${money(client.valor_estimado)}</strong><span>Estimado</span></div>
    <div><strong>${formatDate(client.last_contact_at)}</strong><span>Último contato</span></div>
    <div><strong>${escapeHtml(profileName(client.owner_id))}</strong><span>Dono</span></div>
  </button>`;
}

function renderPipeline() {
  const search = $("pipelineSearch").value.trim().toLowerCase();
  const owner = $("pipelineOwnerFilter").value;
  const filtered = state.clients.filter((client) => {
    const haystack = [client.nome, client.municipio, client.nucleo, client.remessa].join(" ").toLowerCase();
    return (!search || haystack.includes(search)) && (!owner || client.owner_id === owner);
  });

  $("pipelineBoard").innerHTML = CLIENT_STATUSES.map((status) => {
    const list = filtered.filter((client) => client.status === status);
    return `<section class="kanban-column">
      <div class="kanban-head"><h3>${escapeHtml(status)}</h3><span>${list.length}</span></div>
      ${list.map((client) => `<article class="kanban-card"><button data-open-client="${client.id}"><strong>${escapeHtml(client.nome)}</strong><span class="muted">${escapeHtml(client.municipio || "-")} • ${money(client.valor_estimado)}</span><p class="muted">${escapeHtml(client.nucleo || "Sem núcleo")}</p></button></article>`).join("")}
    </section>`;
  }).join("");
}

function renderTickets() {
  const search = $("ticketSearch").value.trim().toLowerCase();
  const municipality = $("ticketMunicipalityFilter").value;
  const nucleus = $("ticketNucleusFilter").value;
  const sector = $("ticketSectorFilter").value;
  const status = $("ticketStatusFilter").value;

  const municipalities = [...new Set(state.tickets.map((ticket) => clientMunicipio(ticket.cliente_id)))].sort((a, b) => a.localeCompare(b, "pt-BR"));
  $("ticketMunicipalityFilter").innerHTML = `<option value="">Todos os municípios</option>${municipalities.map((item) => `<option value="${escapeHtml(item)}">${escapeHtml(item)}</option>`).join("")}`;
  $("ticketMunicipalityFilter").value = municipality;

  const nucleusPool = state.tickets.filter((ticket) => !municipality || clientMunicipio(ticket.cliente_id) === municipality);
  const nucleusOptions = [...new Set(nucleusPool.map((ticket) => clientNucleo(ticket.cliente_id)))].sort((a, b) => a.localeCompare(b, "pt-BR"));
  $("ticketNucleusFilter").innerHTML = `<option value="">Todos os NUIs</option>${nucleusOptions.map((item) => `<option value="${escapeHtml(item)}">${escapeHtml(item)}</option>`).join("")}`;
  $("ticketNucleusFilter").value = nucleusOptions.includes(nucleus) ? nucleus : "";

  const filtered = state.tickets.filter((ticket) => {
    const haystack = [ticket.assunto, ticket.observacao, clientName(ticket.cliente_id)].join(" ").toLowerCase();
    return (!search || haystack.includes(search)) &&
      (!municipality || clientMunicipio(ticket.cliente_id) === municipality) &&
      (!nucleus || clientNucleo(ticket.cliente_id) === nucleus) &&
      (!sector || ticket.setor === sector) && (!status || ticket.status === status);
  });

  $("ticketResultCount").textContent = filtered.length ? `${filtered.length} atendimento(s) encontrado(s).` : "";

  const visible = filtered.slice(0, state.ticketsVisible);
  $("ticketsList").innerHTML = visible.length ? visible.map((ticket) => `
    <article class="record-row">
      <div><h4>${escapeHtml(ticket.assunto)}</h4><p class="muted">${escapeHtml(clientName(ticket.cliente_id))} • ${escapeHtml(clientMunicipio(ticket.cliente_id))} / ${escapeHtml(clientNucleo(ticket.cliente_id))}</p></div>
      <div>${statusBadge(ticket.status)}</div>
      <div><strong>${escapeHtml(ticket.setor)}</strong><p class="muted">${formatDateTime(ticket.created_at)}</p></div>
      <div><span>${escapeHtml(ticket.observacao || "Sem observação")}</span></div>
      <div class="record-actions">
        <button class="secondary small-button" data-open-client="${ticket.cliente_id}">Abrir cliente</button>
        ${ticket.status !== "Resolvido" ? `<button class="primary small-button" data-resolve-ticket="${ticket.id}">Resolver</button>` : ""}
      </div>
    </article>`).join("") : emptyState("Nenhum atendimento encontrado.");

  $("ticketsLoadMore").classList.toggle("hidden", filtered.length <= visible.length);
}

function renderTasks() {
  const search = $("taskSearch").value.trim().toLowerCase();
  const municipality = $("taskMunicipalityFilter").value;
  const nucleus = $("taskNucleusFilter").value;
  const stateFilter = $("taskStateFilter").value;

  const municipalities = [...new Set(state.tasks.map((task) => clientMunicipio(task.cliente_id)))].sort((a, b) => a.localeCompare(b, "pt-BR"));
  $("taskMunicipalityFilter").innerHTML = `<option value="">Todos os municípios</option>${municipalities.map((item) => `<option value="${escapeHtml(item)}">${escapeHtml(item)}</option>`).join("")}`;
  $("taskMunicipalityFilter").value = municipality;

  const nucleusPool = state.tasks.filter((task) => !municipality || clientMunicipio(task.cliente_id) === municipality);
  const nucleusOptions = [...new Set(nucleusPool.map((task) => clientNucleo(task.cliente_id)))].sort((a, b) => a.localeCompare(b, "pt-BR"));
  $("taskNucleusFilter").innerHTML = `<option value="">Todos os NUIs</option>${nucleusOptions.map((item) => `<option value="${escapeHtml(item)}">${escapeHtml(item)}</option>`).join("")}`;
  $("taskNucleusFilter").value = nucleusOptions.includes(nucleus) ? nucleus : "";

  const filtered = state.tasks.filter((task) => {
    const haystack = [task.titulo, clientName(task.cliente_id), profileName(task.assigned_to)].join(" ").toLowerCase();
    const matchesState = stateFilter === "all" || (stateFilter === "done" ? task.concluida : !task.concluida);
    return (!search || haystack.includes(search)) &&
      (!municipality || clientMunicipio(task.cliente_id) === municipality) &&
      (!nucleus || clientNucleo(task.cliente_id) === nucleus) &&
      matchesState;
  });

  $("taskResultCount").textContent = filtered.length ? `${filtered.length} tarefa(s) encontrada(s).` : "";

  const visible = filtered.slice(0, state.tasksVisible);
  $("tasksList").innerHTML = visible.length ? visible.map((task) => `
    <article class="record-row">
      <div><h4>${task.concluida ? "✓ " : ""}${escapeHtml(task.titulo)}</h4><p class="muted">${escapeHtml(clientName(task.cliente_id))} • ${escapeHtml(clientMunicipio(task.cliente_id))} / ${escapeHtml(clientNucleo(task.cliente_id))}</p></div>
      <div><strong>${formatDate(task.data)}</strong><p class="muted">Prazo</p></div>
      <div><strong>${escapeHtml(task.prioridade)}</strong><p class="muted">Prioridade</p></div>
      <div><strong>${escapeHtml(profileName(task.assigned_to))}</strong><p class="muted">Responsável</p></div>
      <div class="record-actions">
        <button class="secondary small-button" data-open-client="${task.cliente_id}">Abrir cliente</button>
        <button class="primary small-button" data-toggle-task="${task.id}">${task.concluida ? "Reabrir" : "Concluir"}</button>
      </div>
    </article>`).join("") : emptyState("Nenhuma tarefa encontrada.");

  $("tasksLoadMore").classList.toggle("hidden", filtered.length <= visible.length);
}

function renderUsers() {
  if (!isAdmin()) return;

  $("usersCount").textContent = state.profiles.length;

  $("usersList").innerHTML = state.profiles.length ? state.profiles.map((profile) => {
    const nickname = profile.apelido || "";
    const initials = (nickname || profile.nome || "U").slice(0, 2).toUpperCase();

    return `<article class="user-table-row" data-user-row="${profile.id}">
      <div class="user-identity-cell">
        <span class="user-avatar">${escapeHtml(initials)}</span>
        <div>
          <input
            class="user-nickname-input"
            data-user-nickname="${profile.id}"
            value="${escapeHtml(nickname)}"
            placeholder="definir usuário"
            maxlength="30"
            aria-label="Nome de usuário"
          />
          <small>${nickname ? `@${escapeHtml(nickname)}` : "Sem nome de usuário"}</small>
        </div>
      </div>

      <div class="user-fullname-cell">
        <strong>${escapeHtml(profile.nome)}</strong>
        <span>Criado em ${formatDate(profile.created_at)}</span>
      </div>

      <label class="user-select-cell">
        <span class="mobile-field-label">Perfil</span>
        <select data-user-role="${profile.id}">
          <option value="usuario" ${profile.perfil === "usuario" ? "selected" : ""}>Usuário</option>
          <option value="marketing" ${profile.perfil === "marketing" ? "selected" : ""}>Marketing</option>
          <option value="admin" ${profile.perfil === "admin" ? "selected" : ""}>Administrador</option>
        </select>
      </label>

      <label class="user-select-cell">
        <span class="mobile-field-label">Status</span>
        <select data-user-active="${profile.id}">
          <option value="true" ${profile.ativo ? "selected" : ""}>Ativo</option>
          <option value="false" ${!profile.ativo ? "selected" : ""}>Desativado</option>
        </select>
      </label>
    </article>`;
  }).join("") : emptyState("Nenhum usuário encontrado.");
}

function marketingProgressFor(projectId) {
  const rows = state.marketingProgress.filter((row) => row.projeto_id === projectId);
  const total = state.marketingEtapas.length;
  const done = rows.filter((row) => row.concluida).length;
  const pendingEtapas = state.marketingEtapas
    .filter((etapa) => !rows.find((row) => row.etapa_id === etapa.id)?.concluida)
    .sort((a, b) => a.ordem - b.ordem);
  const currentFase = pendingEtapas.length ? pendingEtapas[0].fase_numero : (state.marketingEtapas[state.marketingEtapas.length - 1]?.fase_numero || 1);
  const currentFaseNome = pendingEtapas.length ? pendingEtapas[0].fase_nome : "Jornada concluída";
  return { total, done, rows, currentFase, currentFaseNome, completed: total > 0 && done === total };
}


function projectClientCount(projectId) {
  return state.clients.filter((client) => client.projeto_id === projectId).length;
}

function latestProjectProgress(projectId) {
  return state.projectProgress.find((item) => item.projeto_id === projectId);
}

function renderBreadcrumb(elementId, items, crumbAttr) {
  const el = $(elementId);
  if (!el) return;
  el.innerHTML = items.map((item, idx) => {
    const isLast = idx === items.length - 1;
    const label = escapeHtml(item.label);
    if (isLast) return `<span class="breadcrumb-current">${label}</span>`;
    return `<button type="button" class="breadcrumb-link" data-${crumbAttr}="${item.action}">${label}</button><span class="breadcrumb-sep">/</span>`;
  }).join("");
}

function projectCardHtml(project, { selectable = true } = {}) {
  const last = latestProjectProgress(project.id);
  return `<article class="project-card">
    <div class="project-card-head">
      <div><p class="eyebrow">${escapeHtml(project.cidade)}/${escapeHtml(project.estado)}</p><h3>${escapeHtml(project.nome)}</h3></div>
      <span class="badge ${project.ativo ? "closed" : "lost"}">${project.ativo ? "Ativo" : "Inativo"}</span>
    </div>
    <div class="project-card-stats">
      <div><strong>${projectClientCount(project.id)}</strong><span>clientes vinculados</span></div>
      <div><strong>${escapeHtml(last?.status || "Sem andamento")}</strong><span>status atual</span></div>
    </div>
    <p class="muted">${escapeHtml(last?.descricao_cliente || project.observacoes || "Sem observações registradas.")}</p>
    <div class="project-card-actions">
      ${selectable ? `<button class="secondary small-button" type="button" data-select-project="${project.id}">Ver detalhes</button>` : ""}
      ${isAdmin() ? `<button class="secondary small-button" type="button" data-edit-project="${project.id}">Editar</button>` : ""}
    </div>
  </article>`;
}

function renderProjects() {
  if (!$("projectsGrid")) return;
  $("projectSchemaNotice").classList.toggle("hidden", state.projectSchemaReady);
  $("newProjectButton").disabled = !state.projectSchemaReady;

  if (!state.projectSchemaReady) {
    $("projectsGrid").innerHTML = "";
    if ($("projectsBreadcrumb")) $("projectsBreadcrumb").innerHTML = "";
    return;
  }

  const search = $("projectSearch").value.trim().toLowerCase();
  const uf = $("projectStateFilter").value;
  const activeFilter = $("projectActiveFilter").value;

  const states = [...new Set(state.projects.map((p) => p.estado).filter(Boolean))].sort();
  $("projectStateFilter").innerHTML = `<option value="">Todos os estados</option>${states.map((item) => `<option>${escapeHtml(item)}</option>`).join("")}`;
  $("projectStateFilter").value = states.includes(uf) ? uf : "";

  const drill = state.projectsDrill;
  const groups = groupProjectsByMunicipio(state.projects);

  // Valida o estado de navegação contra os dados disponíveis.
  if (drill.municipio && !groups.some((g) => g.key === drill.municipio)) {
    drill.municipio = null;
    drill.projetoId = null;
  }
  if (drill.projetoId && !projectById(drill.projetoId)) drill.projetoId = null;

  if ($("projectStateFilter")) $("projectStateFilter").classList.toggle("hidden", !!drill.municipio);
  if ($("projectActiveFilter")) $("projectActiveFilter").classList.toggle("hidden", !drill.municipio || !!drill.projetoId);
  if ($("projectSearch")) $("projectSearch").classList.toggle("hidden", !!drill.projetoId);

  // ---- Nível 3: detalhe do projeto ----
  if (drill.municipio && drill.projetoId) {
    const project = projectById(drill.projetoId);
    const group = groups.find((g) => g.key === drill.municipio);
    renderBreadcrumb("projectsBreadcrumb", [
      { label: "Municípios", action: "root" },
      { label: `${group.cidade}/${group.estado}`, action: `municipio:${drill.municipio}` },
      { label: project.nome },
    ], "projects-crumb");

    const last = latestProjectProgress(project.id);
    const history = state.projectProgress
      .filter((row) => row.projeto_id === project.id)
      .sort((a, b) => new Date(b.data_atualizacao || b.created_at) - new Date(a.data_atualizacao || a.created_at))
      .slice(0, 3);

    $("projectsGrid").innerHTML = `
      <article class="panel project-detail-panel">
        <div class="project-card-head">
          <div><p class="eyebrow">${escapeHtml(project.cidade)}/${escapeHtml(project.estado)}</p><h2>${escapeHtml(project.nome)}</h2></div>
          <span class="badge ${project.ativo ? "closed" : "lost"}">${project.ativo ? "Ativo" : "Inativo"}</span>
        </div>
        <div class="project-card-stats">
          <div><strong>${projectClientCount(project.id)}</strong><span>clientes vinculados</span></div>
          <div><strong>${escapeHtml(last?.status || "Sem andamento")}</strong><span>status atual</span></div>
        </div>
        <p class="muted">${escapeHtml(project.observacoes || "Sem observações registradas.")}</p>
        <div class="project-card-actions">
          <button class="primary small-button" type="button" data-open-project-progress="${project.id}">Ver andamentos completos</button>
          ${isAdmin() ? `<button class="secondary small-button" type="button" data-edit-project="${project.id}">Editar projeto</button>` : ""}
        </div>
        ${history.length ? `<div class="project-timeline" style="margin-top:18px">
          ${history.map((item) => `<div class="project-timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
              <div class="timeline-title"><div><strong>${escapeHtml(item.status)}</strong></div><time>${formatDate(item.data_atualizacao || item.created_at)}</time></div>
              <p>${escapeHtml(item.descricao_cliente)}</p>
            </div>
          </div>`).join("")}
        </div>` : `<p class="muted" style="margin-top:16px">Nenhum andamento registrado ainda.</p>`}
      </article>`;
    return;
  }

  // ---- Nível 2: projetos do município ----
  if (drill.municipio) {
    const group = groups.find((g) => g.key === drill.municipio);
    if (!group) { drill.municipio = null; renderProjects(); return; }
    renderBreadcrumb("projectsBreadcrumb", [
      { label: "Municípios", action: "root" },
      { label: `${group.cidade}/${group.estado}` },
    ], "projects-crumb");

    const filtered = group.projects.filter((project) => {
      const haystack = [project.nome, project.observacoes].join(" ").toLowerCase();
      const matchesActive = activeFilter === "all" || (activeFilter === "active" ? project.ativo : !project.ativo);
      return (!search || haystack.includes(search)) && matchesActive;
    });

    $("projectsGrid").innerHTML = filtered.length
      ? filtered.map((project) => projectCardHtml(project)).join("")
      : emptyState("Nenhum projeto encontrado neste município.");
    return;
  }

  // ---- Nível 1: municípios ----
  renderBreadcrumb("projectsBreadcrumb", [{ label: "Municípios" }], "projects-crumb");

  const filteredGroups = groups.filter((group) => {
    const haystack = `${group.cidade} ${group.estado}`.toLowerCase();
    return (!search || haystack.includes(search)) && (!uf || group.estado === uf);
  });

  $("projectsGrid").innerHTML = filteredGroups.length ? filteredGroups.map((group) => {
    const activeCount = group.projects.filter((p) => p.ativo).length;
    const clientTotal = group.projects.reduce((sum, p) => sum + projectClientCount(p.id), 0);
    return `<button type="button" class="project-card municipio-card" data-select-municipio="${group.key}">
      <div class="project-card-head"><div><p class="eyebrow">${escapeHtml(group.estado)}</p><h3>${escapeHtml(group.cidade)}</h3></div></div>
      <div class="project-card-stats">
        <div><strong>${group.projects.length}</strong><span>projeto(s) • ${activeCount} ativo(s)</span></div>
        <div><strong>${clientTotal}</strong><span>clientes vinculados</span></div>
      </div>
    </button>`;
  }).join("") : emptyState("Nenhum município encontrado.");
}

function renderProjectProgress() {
  if (!$("progressProjectsList")) return;

  $("progressSchemaNotice").classList.toggle("hidden", state.projectSchemaReady);
  $("newProgressButton").disabled = !state.projectSchemaReady;

  if (!state.projectSchemaReady) {
    $("progressProjectsList").innerHTML = "";
    $("progressSummary").innerHTML = "";
    if ($("progressBreadcrumb")) $("progressBreadcrumb").innerHTML = "";
    return;
  }

  const drill = state.progressDrill;
  const groups = groupProjectsByMunicipio(state.projects);

  if (drill.municipio && !groups.some((g) => g.key === drill.municipio)) {
    drill.municipio = null;
    drill.projetoId = null;
  }
  if (drill.projetoId && !projectById(drill.projetoId)) drill.projetoId = null;

  const search = $("progressSearch").value.trim().toLowerCase();
  const status = $("progressStatusFilter").value;
  const selectedState = $("progressStateFilter").value;
  const activity = $("progressActivityFilter").value;

  const availableStates = [...new Set(state.projects.map((p) => p.estado).filter(Boolean))].sort();
  const currentStateValue = $("progressStateFilter").value;
  $("progressStateFilter").innerHTML =
    `<option value="">Todos os estados</option>` +
    availableStates.map((uf) => `<option value="${escapeHtml(uf)}">${escapeHtml(uf)}</option>`).join("");
  $("progressStateFilter").value = availableStates.includes(currentStateValue) ? currentStateValue : "";

  $("progressStateFilter").classList.toggle("hidden", !!drill.municipio);
  $("progressStatusFilter").classList.toggle("hidden", !drill.municipio || !!drill.projetoId);
  $("progressActivityFilter").classList.toggle("hidden", !drill.municipio || !!drill.projetoId);
  $("progressSearch").classList.toggle("hidden", !!drill.projetoId);

  const allProjectsWithMeta = state.projects.map((project) => {
    const items = state.projectProgress
      .filter((row) => row.projeto_id === project.id)
      .sort((a, b) => {
        const da = new Date(a.data_atualizacao || a.created_at || 0);
        const db = new Date(b.data_atualizacao || b.created_at || 0);
        return db - da;
      });
    return {
      project,
      items,
      current: items[0] || null,
      clientCount: projectClientCount(project.id),
    };
  });

  // ---- Nível 3: histórico completo de um projeto ----
  if (drill.municipio && drill.projetoId) {
    const meta = allProjectsWithMeta.find((m) => m.project.id === drill.projetoId);
    if (!meta) { drill.projetoId = null; renderProjectProgress(); return; }
    const { project, items, clientCount } = meta;

    renderBreadcrumb("progressBreadcrumb", [
      { label: "Municípios", action: "root" },
      { label: `${project.cidade}/${project.estado}`, action: `municipio:${drill.municipio}` },
      { label: project.nome },
    ], "progress-crumb");

    $("progressSummary").innerHTML = "";
    $("progressResultsTitle").textContent = project.nome;
    $("progressResultsCount").textContent = `${items.length} registro(s) • ${clientCount} cliente(s) vinculado(s)`;

    $("progressProjectsList").innerHTML = `
      <div class="progress-row-details-head" style="padding:18px 20px 0">
        <div>
          <strong>Histórico de andamentos</strong>
          <span class="muted">Atualizações vinculadas a todos os clientes deste Projeto/Núcleo.</span>
        </div>
        <button class="primary small-button" type="button" data-new-progress-project="${project.id}">+ Registrar andamento</button>
      </div>
      <div class="project-timeline" style="padding:18px 20px">
        ${items.length ? items.map((item) => `<div class="project-timeline-item">
          <div class="timeline-dot"></div>
          <div class="timeline-content">
            <div class="timeline-title">
              <div>
                <strong>${escapeHtml(item.status)}</strong>
                <span class="ai-visibility">${item.visivel_ia ? "Disponível para IA" : "Somente equipe"}</span>
              </div>
              <time>${formatDate(item.data_atualizacao || item.created_at)}</time>
            </div>
            <p>${escapeHtml(item.descricao_cliente)}</p>
            ${item.observacao_interna ? `<details>
              <summary>Observação interna</summary>
              <p class="muted">${escapeHtml(item.observacao_interna)}</p>
            </details>` : ""}
            <div class="timeline-actions">
              <button class="danger-text-button" type="button"
                data-delete-progress="${item.id}"
                data-delete-progress-project="${project.id}">
                Excluir andamento
              </button>
            </div>
          </div>
        </div>`).join("") : emptyState("Nenhum andamento registrado para este projeto.")}
      </div>`;
    return;
  }

  // ---- Nível 2: projetos do município ----
  if (drill.municipio) {
    const group = groups.find((g) => g.key === drill.municipio);
    if (!group) { drill.municipio = null; renderProjectProgress(); return; }

    renderBreadcrumb("progressBreadcrumb", [
      { label: "Municípios", action: "root" },
      { label: `${group.cidade}/${group.estado}` },
    ], "progress-crumb");

    let metas = allProjectsWithMeta.filter((m) => municipioKeyOf(m.project) === drill.municipio);
    metas = metas.filter(({ project, items, current }) => {
      const text = [project.nome, project.observacoes, ...items.map((row) => `${row.status} ${row.descricao_cliente || ""}`)].join(" ").toLowerCase();
      const statusMatch = !status || current?.status === status || items.some((row) => row.status === status);
      const activityMatch =
        activity === "all" ||
        (activity === "with_progress" && items.length > 0) ||
        (activity === "without_progress" && items.length === 0);
      return (!search || text.includes(search)) && statusMatch && activityMatch;
    });

    const withProgress = metas.filter((m) => m.items.length > 0).length;
    $("progressSummary").innerHTML = `
      <article class="progress-summary-card"><span>Projetos no município</span><strong>${group.projects.length}</strong></article>
      <article class="progress-summary-card"><span>Com atualização</span><strong>${withProgress}</strong></article>
      <article class="progress-summary-card"><span>Sem andamento</span><strong>${group.projects.length - withProgress}</strong></article>
      <article class="progress-summary-card"><span>Clientes vinculados</span><strong>${group.projects.reduce((sum, p) => sum + projectClientCount(p.id), 0)}</strong></article>`;

    $("progressResultsTitle").textContent = `${group.cidade}/${group.estado}`;
    $("progressResultsCount").textContent = `${metas.length} de ${group.projects.length} projeto(s)`;

    $("progressProjectsList").innerHTML = metas.length ? metas.map(({ project, items, current, clientCount }) => {
      const lastDate = current ? formatDate(current.data_atualizacao || current.created_at) : "Sem atualização";
      const statusText = current?.status || "Sem andamento";
      const publicText = current?.descricao_cliente || "Nenhuma atualização registrada para este Projeto/Núcleo.";
      return `<button type="button" class="progress-row-summary" data-select-progress-project="${project.id}">
        <div class="progress-row-project">
          <div>
            <strong>${escapeHtml(project.nome)}</strong>
            <span>${clientCount} cliente(s) vinculado(s)</span>
          </div>
        </div>
        <div class="progress-row-status">
          <span class="progress-status-chip">${escapeHtml(statusText)}</span>
          <span class="muted">${escapeHtml(lastDate)}</span>
        </div>
        <div class="progress-row-text">${escapeHtml(publicText)}</div>
        <div class="progress-row-count">${items.length} registro(s)</div>
      </button>`;
    }).join("") : emptyState("Nenhum projeto encontrado com os filtros selecionados.");
    return;
  }

  // ---- Nível 1: municípios ----
  renderBreadcrumb("progressBreadcrumb", [{ label: "Municípios" }], "progress-crumb");

  let filteredGroups = groups;
  if (selectedState) filteredGroups = filteredGroups.filter((g) => g.estado === selectedState);
  if (search) filteredGroups = filteredGroups.filter((g) => `${g.cidade} ${g.estado}`.toLowerCase().includes(search));

  const totalProjects = state.projects.length;
  const withProgressTotal = allProjectsWithMeta.filter((m) => m.items.length > 0).length;
  $("progressSummary").innerHTML = `
    <article class="progress-summary-card"><span>Total de projetos</span><strong>${totalProjects}</strong></article>
    <article class="progress-summary-card"><span>Com atualização</span><strong>${withProgressTotal}</strong></article>
    <article class="progress-summary-card"><span>Sem andamento</span><strong>${totalProjects - withProgressTotal}</strong></article>
    <article class="progress-summary-card"><span>Municípios</span><strong>${groups.length}</strong></article>`;

  $("progressResultsTitle").textContent = "Municípios";
  $("progressResultsCount").textContent = `${filteredGroups.length} de ${groups.length} município(s)`;

  $("progressProjectsList").innerHTML = filteredGroups.length ? filteredGroups.map((group) => {
    const metas = allProjectsWithMeta.filter((m) => municipioKeyOf(m.project) === group.key);
    const withProgress = metas.filter((m) => m.items.length > 0).length;
    return `<button type="button" class="progress-row-summary" data-select-progress-municipio="${group.key}">
      <div class="progress-row-project">
        <div>
          <strong>${escapeHtml(group.cidade)}/${escapeHtml(group.estado)}</strong>
          <span>${group.projects.length} projeto(s)</span>
        </div>
      </div>
      <div class="progress-row-status">
        <span class="progress-status-chip">${withProgress} com atualização</span>
      </div>
      <div class="progress-row-text muted">${group.projects.length - withProgress} sem andamento registrado</div>
      <div class="progress-row-count"></div>
    </button>`;
  }).join("") : emptyState("Nenhum município encontrado.");
}

async function deleteProjectProgress(progressId, projectId) {
  const item = state.projectProgress.find((row) => row.id === progressId);
  if (!item) return showToast("Andamento não encontrado.", "error");

  const project = projectById(projectId || item.projeto_id);
  const confirmed = window.confirm(
    `Excluir este andamento de "${project?.nome || "Projeto/Núcleo"}"?\n\n` +
    `Status: ${item.status}\n` +
    `Data: ${formatDate(item.data_atualizacao || item.created_at)}\n\n` +
    `Esta ação remove somente este registro de andamento. O projeto e os clientes não serão excluídos.`
  );

  if (!confirmed) return;

  const { error } = await supabase.from("andamentos").delete().eq("id", progressId);
  if (error) return showToast(error.message, "error");

  await loadData();
  showToast("Andamento excluído.");
}

function openProjectDialog(project = null, prefill = null) {
  if (!state.projectSchemaReady) return showToast("Primeiro aplique a migração de Projetos no Supabase.", "error");
  $("projectForm").reset();
  $("projectId").value = project?.id || "";
  $("projectDialogTitle").textContent = project ? "Editar projeto" : "Novo projeto";
  $("projectName").value = project?.nome || "";
  $("projectCity").value = project?.cidade || prefill?.cidade || "";
  $("projectState").value = project?.estado || prefill?.estado || "";
  $("projectActive").value = String(project?.ativo ?? true);
  $("projectNotes").value = project?.observacoes || "";
  $("projectDialog").showModal();
}

async function saveProject(event) {
  event.preventDefault();
  const id = $("projectId").value;
  const payload = {
    nome: $("projectName").value.trim(),
    cidade: $("projectCity").value.trim(),
    estado: $("projectState").value.trim().toUpperCase(),
    ativo: $("projectActive").value === "true",
    observacoes: $("projectNotes").value.trim() || null,
  };
  let result;
  if (id) result = await supabase.from("projetos").update(payload).eq("id", id);
  else result = await supabase.from("projetos").insert({ ...payload, created_by: state.user.id });
  if (result.error) return showToast(result.error.message, "error");
  $("projectDialog").close();
  if (!id) {
    state.projectsDrill.municipio = municipioKeyOf(payload);
    state.projectsDrill.projetoId = null;
  }
  await loadData();
  showToast(id ? "Projeto atualizado." : "Projeto criado.");
}

function openProgressDialog(projectId = "") {
  if (!state.projectSchemaReady) return showToast("Primeiro aplique a migração de Andamentos no Supabase.", "error");
  $("progressForm").reset();
  $("progressDate").value = today();
  $("progressVisibleAi").checked = true;
  $("progressProject").value = projectId;
  $("progressDialog").showModal();
}

async function saveProjectProgress(event) {
  event.preventDefault();
  const projetoId = $("progressProject").value;
  const payload = {
    projeto_id: projetoId,
    status: $("progressStatus").value,
    descricao_cliente: $("progressPublicText").value.trim(),
    observacao_interna: $("progressInternalText").value.trim() || null,
    visivel_ia: $("progressVisibleAi").checked,
    data_atualizacao: $("progressDate").value,
    created_by: state.user.id,
  };
  const { error } = await supabase.from("andamentos").insert(payload);
  if (error) return showToast(error.message, "error");
  $("progressDialog").close();
  const project = projectById(projetoId);
  if (project) {
    state.progressDrill.municipio = municipioKeyOf(project);
    state.progressDrill.projetoId = project.id;
  }
  await loadData();
  setView("andamentos");
  showToast("Andamento registrado para todo o Projeto/Núcleo.");
}

function applyProjectToClientForm() {
  const project = projectById($("clientProject").value);
  if (!project) return;
  $("clientState").value = project.estado || "";
  $("clientMunicipality").value = project.cidade || "";
  $("clientNucleus").value = project.nome || "";
}

function renderMarketingProjects() {
  if (!isMarketingTeam()) return;
  const search = $("marketingSearch").value.trim().toLowerCase();
  const statusFilter = $("marketingStatusFilter").value;

  const filtered = state.marketingProjects.filter((project) => {
    const matchesSearch = !search || project.municipio.toLowerCase().includes(search);
    const progress = marketingProgressFor(project.id);
    const matchesStatus = !statusFilter || (statusFilter === "concluido" ? progress.completed : !progress.completed);
    return matchesSearch && matchesStatus;
  });

  $("marketingProjectsGrid").innerHTML = filtered.length
    ? filtered.map(marketingProjectCard).join("")
    : emptyState("Nenhum município cadastrado no controle de marketing.");
}

function marketingProjectCard(project) {
  const progress = marketingProgressFor(project.id);
  const pct = progress.total ? Math.round((progress.done / progress.total) * 100) : 0;
  const color = MARKETING_FASE_COLORS[progress.currentFase] || "var(--primary)";
  return `<article class="marketing-project-card">
    <button data-open-marketing-project="${project.id}">
      <div class="marketing-project-head">
        <h3>${escapeHtml(projectById(project.projeto_id)?.nome || project.municipio)}</h3>
        <span class="marketing-phase-pill" style="background:${color}">${escapeHtml(progress.currentFaseNome)}</span>
      </div>
      <div class="marketing-progress-bar"><div class="marketing-progress-fill" style="width:${pct}%; background:${color}"></div></div>
      <div class="marketing-progress-label"><span>${progress.done} de ${progress.total} etapas</span><span>${pct}%</span></div>
    </button>
  </article>`;
}

function openMarketingProjectDialog() {
  $("marketingProjectForm").reset();
  $("marketingProjectDialog").showModal();
}

async function saveMarketingProject(event) {
  event.preventDefault();
  const projetoId = $("marketingProjectSelect").value;
  const linkedProject = projectById(projetoId);
  if (!linkedProject) return showToast("Selecione um Projeto/Núcleo cadastrado.", "error");
  const { error } = await supabase.from("marketing_projetos").insert({
    projeto_id: projetoId,
    municipio: linkedProject.cidade,
    observacoes: $("marketingObservacoes").value.trim() || null,
    created_by: state.user.id,
  });
  if (error) return showToast(error.message, "error");
  $("marketingProjectDialog").close();
  await loadData();
  showToast("Projeto vinculado ao Controle de Marketing.");
}

function openMarketingJourney(projectId) {
  state.selectedMarketingProjectId = projectId;
  renderMarketingJourney(projectId);
  $("marketingJourneyDialog").showModal();
}

function renderMarketingJourney(projectId) {
  const project = state.marketingProjects.find((item) => item.id === projectId);
  if (!project) return;

  const progress = marketingProgressFor(projectId);
  const pct = progress.total ? Math.round((progress.done / progress.total) * 100) : 0;

  const linkedProject = projectById(project.projeto_id);
  $("marketingJourneyTitle").textContent = linkedProject?.nome || project.municipio;
  $("marketingJourneySubtitle").textContent = linkedProject ? `${linkedProject.cidade}/${linkedProject.estado} • ${projectClientCount(linkedProject.id)} cliente(s) vinculados` : (project.observacoes || "Sem observações registradas.");
  $("marketingJourneyProgress").innerHTML = `
    <div class="marketing-progress-bar"><div class="marketing-progress-fill" style="width:${pct}%"></div></div>
    <strong>${progress.done}/${progress.total} etapas concluídas</strong>`;

  const fases = [...new Map(state.marketingEtapas.map((etapa) => [etapa.fase_numero, etapa.fase_nome])).entries()].sort((a, b) => a[0] - b[0]);

  $("marketingJourneyPhases").innerHTML = fases.map(([faseNumero, faseNome]) => {
    const color = MARKETING_FASE_COLORS[faseNumero] || "var(--primary)";
    const etapas = state.marketingEtapas.filter((etapa) => etapa.fase_numero === faseNumero).sort((a, b) => a.ordem - b.ordem);
    const rows = etapas.map((etapa) => {
      const progressRow = state.marketingProgress.find((row) => row.projeto_id === projectId && row.etapa_id === etapa.id);
      const done = progressRow?.concluida;
      const meta = done
        ? `Concluída por ${escapeHtml(profileName(progressRow.concluida_por))} em ${formatDateTime(progressRow.concluida_em)}`
        : "Pendente";
      return `<div class="marketing-etapa-row">
        <div class="marketing-etapa-info">
          <strong>${escapeHtml(etapa.codigo)} — ${escapeHtml(etapa.titulo)}</strong>
          <span>${escapeHtml(etapa.descricao || "")}</span>
          <span class="marketing-etapa-meta">${meta}</span>
        </div>
        <button type="button" class="${done ? "secondary" : "primary"} small-button marketing-etapa-toggle" data-toggle-marketing-etapa="${progressRow?.id || ""}">${done ? "Reabrir" : "Concluir"}</button>
      </div>`;
    }).join("");
    return `<article class="marketing-phase-section" style="border-left-color:${color}">
      <h3><span class="marketing-phase-number" style="background:${color}">${faseNumero}</span> ${escapeHtml(faseNome)}</h3>
      ${rows}
    </article>`;
  }).join("");
}

async function toggleMarketingEtapa(progressId) {
  const row = state.marketingProgress.find((item) => item.id === progressId);
  if (!row) return;
  const willComplete = !row.concluida;
  const { error } = await supabase.from("marketing_progresso").update({
    concluida: willComplete,
    concluida_em: willComplete ? new Date().toISOString() : null,
    concluida_por: willComplete ? state.user.id : null,
  }).eq("id", progressId);
  if (error) return showToast(error.message, "error");
  await loadData();
  showToast(willComplete ? "Etapa marcada como concluída." : "Etapa reaberta.");
}

function emptyState(message) {
  return `<div class="empty-state">${escapeHtml(message)}</div>`;
}

function setView(view) {
  if (view === "usuarios" && !isAdmin()) view = "dashboard";
  if (view === "marketing" && !isMarketingTeam()) view = "dashboard";
  state.currentView = view;
  document.querySelectorAll(".view").forEach((element) => element.classList.toggle("active", element.id === view));
  document.querySelectorAll(".nav-button").forEach((button) => button.classList.toggle("active", button.dataset.view === view));

  const labels = {
    dashboard: ["Visão geral", "Dashboard", "Acompanhe comercial, atendimento e agenda."],
    clientes: ["Base de clientes", "Clientes cadastrados", "Cards organizados automaticamente por município."],
    funil: ["Comercial", "Funil comercial", "Acompanhe as oportunidades por etapa."],
    atendimentos: ["Atendimento", "Atendimentos", "Demandas dos setores Atendimento, Comercial, Financeiro, Projetos, Topografia e Pós-Protocolo, incluindo contatos sincronizados do Chatwoot."],
    tarefas: ["Agenda", "Tarefas", "Controle de prazos e responsabilidades."],
    projetos: ["Estrutura", "Projetos / Núcleos Urbanos", "Cadastre os núcleos e vincule grupos de clientes à mesma cidade e estado."],
    andamentos: ["Pós-venda", "Andamentos", "Atualizações coletivas por Projeto/Núcleo, prontas para consulta pelo agente IA."],
    marketing: ["Pós-venda", "Controle de Marketing", "Jornada do cliente por município nos grupos de WhatsApp."],
    usuarios: ["Administração", "Usuários", "Perfis, acessos e permissões da equipe."],
  };
  const [eyebrow, title, description] = labels[view];
  $("pageEyebrow").textContent = eyebrow;
  $("pageTitle").textContent = title;
  $("pageDescription").textContent = description;
}

function openNewClient() {
  $("clientForm").reset();
  $("clientId").value = "";
  $("clientFormTitle").textContent = "Novo cliente";
  $("deleteClientButton").classList.add("hidden");
  $("clientStatus").value = "Novo";
  if ($("clientProject")) $("clientProject").value = "";
  if ($("clientState")) $("clientState").value = "";
  $("clientResponsible").value = state.profile.nome;
  $("clientOwner").value = state.user.id;
  $("clientFormDialog").showModal();
}

function openEditClient(client) {
  if (!client) return;
  $("clientId").value = client.id;
  $("clientFormTitle").textContent = "Editar cliente";
  $("clientName").value = client.nome || "";
  $("clientPhone").value = client.telefone || "";
  $("clientEmail").value = client.email || "";
  $("clientProject").value = client.projeto_id || "";
  $("clientState").value = client.estado || clientProject(client)?.estado || "";
  $("clientMunicipality").value = client.municipio || "";
  $("clientNucleus").value = client.nucleo || "";
  $("clientShipment").value = client.remessa || "";
  $("clientSource").value = client.origem || "Indicação";
  $("clientStatus").value = client.status || "Novo";
  $("clientValue").value = client.valor_estimado || 0;
  $("clientResponsible").value = client.responsavel || "";
  $("clientOwner").value = client.owner_id;
  $("clientNotes").value = client.observacoes || "";
  $("deleteClientButton").classList.remove("hidden");
  $("clientFormDialog").showModal();
}

async function saveClient(event) {
  event.preventDefault();
  const id = $("clientId").value;
  const existing = state.clients.find((client) => client.id === id);
  const ownerId = isAdmin() ? $("clientOwner").value : (existing?.owner_id || state.user.id);
  const payload = {
    owner_id: ownerId,
    nome: $("clientName").value.trim(),
    telefone: $("clientPhone").value.trim() || null,
    telefone_normalizado: $("clientPhone").value.trim() ? $("clientPhone").value.replace(/\D/g, "") : null,
    email: $("clientEmail").value.trim() || null,
    projeto_id: state.projectSchemaReady ? ($("clientProject").value || null) : (existing?.projeto_id || null),
    estado: $("clientState").value.trim().toUpperCase() || null,
    municipio: $("clientMunicipality").value.trim() || null,
    nucleo: $("clientNucleus").value.trim() || null,
    remessa: $("clientShipment").value.trim() || null,
    origem: $("clientSource").value,
    status: $("clientStatus").value,
    valor_estimado: Number($("clientValue").value || 0),
    responsavel: $("clientResponsible").value.trim() || null,
    observacoes: $("clientNotes").value.trim() || null,
  };

  setSync("loading", "Salvando...");
  let result;
  if (existing) {
    result = await supabase.from("clientes").update(payload).eq("id", id).select().single();
  } else {
    result = await supabase.from("clientes").insert({ ...payload, created_by: state.user.id }).select().single();
  }

  if (result.error) {
    setSync("error", "Erro ao salvar");
    return showToast(result.error.message, "error");
  }

  if (existing) {
    const changes = describeClientChanges(existing, payload);
    if (changes.length) {
      await supabase.from("historico").insert({ cliente_id: id, created_by: state.user.id, tipo: "Dados atualizados", descricao: changes.join("\n") });
    }
  } else {
    await supabase.from("historico").insert({ cliente_id: result.data.id, created_by: state.user.id, tipo: "Cliente cadastrado", descricao: `Cadastro criado por ${state.profile.nome}.` });
  }

  $("clientFormDialog").close();
  await loadData();
  showToast(existing ? "Cliente atualizado." : "Cliente cadastrado.");
}

function describeClientChanges(oldClient, payload) {
  const fields = {
    nome: "Nome", telefone: "Telefone", email: "E-mail", projeto_id: "Projeto", estado: "Estado", municipio: "Município", nucleo: "Núcleo", remessa: "Remessa",
    origem: "Origem", status: "Status", valor_estimado: "Valor estimado", responsavel: "Responsável", observacoes: "Observações", owner_id: "Dono do registro",
  };
  return Object.entries(fields).flatMap(([key, label]) => {
    const before = oldClient[key] ?? "";
    const after = payload[key] ?? "";
    if (String(before) === String(after)) return [];
    const format = (value) => key === "valor_estimado" ? money(value) : key === "owner_id" ? profileName(value) : key === "projeto_id" ? projectLabel(projectById(value)) : String(value || "Não informado");
    return [`${label}: ${format(before)} → ${format(after)}`];
  });
}

async function deleteClient() {
  const id = $("clientId").value;
  if (!id || !confirm("Excluir este cliente e todo o histórico relacionado?")) return;
  const { error } = await supabase.from("clientes").delete().eq("id", id);
  if (error) return showToast(error.message, "error");
  $("clientFormDialog").close();
  $("clientDetailDialog").close();
  state.selectedClientId = null;
  await loadData();
  showToast("Cliente excluído.");
}

function renderClientDetail(clientId) {
  const client = state.clients.find((item) => item.id === clientId);
  if (!client) return;
  state.selectedClientId = clientId;

  $("detailLocation").textContent = client.municipio || "Sem município";
  $("detailName").textContent = client.nome;
  const linkedProject = clientProject(client);
  $("detailSubtitle").textContent = linkedProject ? `${linkedProject.nome} • ${linkedProject.cidade}/${linkedProject.estado} • Remessa: ${client.remessa || "-"}` : `Núcleo: ${client.nucleo || "-"} • Remessa: ${client.remessa || "-"}`;
  $("detailStatus").innerHTML = statusBadge(client.status);
  $("detailValue").textContent = money(client.valor_estimado);
  $("detailCreated").textContent = formatDate(client.created_at);
  $("detailLastContact").textContent = formatDate(client.last_contact_at);

  const rows = [
    ["Telefone", client.telefone || "-"], ["E-mail", client.email || "-"], ["Projeto / Núcleo", linkedProject?.nome || client.nucleo || "-"],
    ["Estado", client.estado || linkedProject?.estado || "-"], ["Município", client.municipio || linkedProject?.cidade || "-"],
    ["Núcleo", client.nucleo || "-"], ["Remessa", client.remessa || "-"], ["Origem", client.origem || "-"],
    ["Canal", client.canal || "CRM"], ["Último setor", client.ultimo_setor || "-"], ["Último agente", client.ultimo_agente || "-"],
    ["Responsável operacional", client.responsavel || "-"], ["Dono do registro", profileName(client.owner_id)], ["Observações", client.observacoes || "-"],
  ];
  $("detailData").innerHTML = rows.map(([label, value]) => `<div class="detail-data-row"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join("");

  const activity = buildRecentActivity(clientId);
  const creation = { date: client.created_at, title: "Cadastro criado", text: `Responsável inicial: ${profileName(client.owner_id)}`, author: profileName(client.created_by) };
  const timeline = [...activity, creation].sort((a, b) => new Date(b.date) - new Date(a.date));
  $("detailTimeline").innerHTML = timeline.length ? timeline.map((item) => `
    <article class="timeline-item">
      <h4>${escapeHtml(item.title)}</h4>
      <time>${formatDateTime(item.date)} • ${escapeHtml(item.author || "Sistema")}</time>
      <p>${escapeHtml(item.text || "")}</p>
    </article>`).join("") : emptyState("Nenhum histórico registrado.");

  $("taskDueDate").value = today();
  $("taskAssignee").value = client.owner_id || state.user.id;
}

function openClientDetail(clientId) {
  renderClientDetail(clientId);
  $("clientDetailDialog").showModal();
}

async function saveHistory(event) {
  event.preventDefault();
  const { error } = await supabase.from("historico").insert({
    cliente_id: state.selectedClientId,
    created_by: state.user.id,
    tipo: $("historyType").value,
    descricao: $("historyDescription").value.trim(),
  });
  if (error) return showToast(error.message, "error");
  event.target.reset();
  await loadData();
  showToast("Atualização registrada.");
}

async function saveTicket(event) {
  event.preventDefault();
  const { error } = await supabase.from("atendimentos").insert({
    cliente_id: state.selectedClientId,
    created_by: state.user.id,
    setor: $("ticketSector").value,
    assunto: $("ticketSubject").value.trim(),
    status: $("ticketStatus").value,
    observacao: $("ticketNotes").value.trim() || null,
  });
  if (error) return showToast(error.message, "error");
  event.target.reset();
  await loadData();
  showToast("Atendimento registrado.");
}

async function saveTask(event) {
  event.preventDefault();
  const client = state.clients.find((item) => item.id === state.selectedClientId);
  const assignedTo = isAdmin() ? $("taskAssignee").value : state.user.id;
  const { error } = await supabase.from("tarefas").insert({
    cliente_id: state.selectedClientId,
    created_by: state.user.id,
    assigned_to: assignedTo || client.owner_id,
    titulo: $("taskTitle").value.trim(),
    data: $("taskDueDate").value,
    prioridade: $("taskPriority").value,
  });
  if (error) return showToast(error.message, "error");
  event.target.reset();
  $("taskDueDate").value = today();
  await loadData();
  showToast("Tarefa criada.");
}

async function resolveTicket(id) {
  const { error } = await supabase.from("atendimentos").update({ status: "Resolvido" }).eq("id", id);
  if (error) return showToast(error.message, "error");
  await loadData();
  showToast("Atendimento resolvido.");
}

async function toggleTask(id) {
  const task = state.tasks.find((item) => item.id === id);
  if (!task) return;
  const { error } = await supabase.from("tarefas").update({ concluida: !task.concluida }).eq("id", id);
  if (error) return showToast(error.message, "error");
  await loadData();
  showToast(task.concluida ? "Tarefa reaberta." : "Tarefa concluída.");
}

/* ------------------------------------------------------------------
   Seletor de cliente com busca — usado nos diálogos avulsos de
   atendimento e tarefa (sem precisar abrir a ficha do cliente antes).
------------------------------------------------------------------ */
function setupClientPicker(prefix) {
  const input = $(`${prefix}ClientSearch`);
  const hidden = $(`${prefix}ClientId`);
  const results = $(`${prefix}ClientResults`);

  function close() {
    results.classList.add("hidden");
    results.innerHTML = "";
  }

  function search(term) {
    const query = term.trim().toLowerCase();
    if (!query) return close();
    const matches = state.clients.filter((client) => {
      const haystack = [client.nome, client.municipio, client.nucleo].join(" ").toLowerCase();
      return haystack.includes(query);
    }).slice(0, 8);

    if (!matches.length) {
      results.innerHTML = `<div class="client-picker-empty">Nenhum cliente encontrado.</div>`;
      results.classList.remove("hidden");
      return;
    }

    results.innerHTML = matches.map((client) => `
      <button type="button" class="client-picker-option" data-pick-client="${client.id}">
        <strong>${escapeHtml(client.nome)}</strong>
        <span>${escapeHtml(client.municipio || "Sem município")} • ${escapeHtml(client.nucleo || "Sem NUI")}</span>
      </button>`).join("");
    results.classList.remove("hidden");
  }

  input.addEventListener("input", () => {
    hidden.value = "";
    search(input.value);
  });
  input.addEventListener("focus", () => { if (input.value) search(input.value); });

  results.addEventListener("click", (event) => {
    const option = event.target.closest("[data-pick-client]");
    if (!option) return;
    const client = state.clients.find((item) => item.id === option.dataset.pickClient);
    if (!client) return;
    hidden.value = client.id;
    input.value = `${client.nome} — ${client.municipio || "Sem município"} / ${client.nucleo || "Sem NUI"}`;
    close();
  });

  document.addEventListener("click", (event) => {
    if (!event.target.closest(`[data-picker="${prefix}"]`)) close();
  });

  return { reset: () => { input.value = ""; hidden.value = ""; close(); } };
}

function openTicketDialog() {
  $("ticketStandaloneForm").reset();
  $("ticketStandaloneClientId").value = "";
  $("ticketStandaloneClientResults").classList.add("hidden");
  $("ticketStandaloneDialog").showModal();
}

async function saveStandaloneTicket(event) {
  event.preventDefault();
  const clienteId = $("ticketStandaloneClientId").value;
  if (!clienteId) return showToast("Selecione um cliente da lista de sugestões.", "error");

  const { error } = await supabase.from("atendimentos").insert({
    cliente_id: clienteId,
    created_by: state.user.id,
    setor: $("ticketStandaloneSector").value,
    assunto: $("ticketStandaloneSubject").value.trim(),
    status: $("ticketStandaloneStatus").value,
    observacao: $("ticketStandaloneNotes").value.trim() || null,
  });
  if (error) return showToast(error.message, "error");
  $("ticketStandaloneDialog").close();
  await loadData();
  showToast("Atendimento registrado.");
}

function openTaskDialog() {
  $("taskStandaloneForm").reset();
  $("taskStandaloneClientId").value = "";
  $("taskStandaloneClientResults").classList.add("hidden");
  $("taskStandaloneDueDate").value = today();
  $("taskStandaloneDialog").showModal();
}

async function saveStandaloneTask(event) {
  event.preventDefault();
  const clienteId = $("taskStandaloneClientId").value;
  if (!clienteId) return showToast("Selecione um cliente da lista de sugestões.", "error");

  const client = state.clients.find((item) => item.id === clienteId);
  const assignedTo = isAdmin() ? $("taskStandaloneAssignee").value : state.user.id;
  const { error } = await supabase.from("tarefas").insert({
    cliente_id: clienteId,
    created_by: state.user.id,
    assigned_to: assignedTo || client?.owner_id,
    titulo: $("taskStandaloneTitle").value.trim(),
    data: $("taskStandaloneDueDate").value,
    prioridade: $("taskStandalonePriority").value,
  });
  if (error) return showToast(error.message, "error");
  $("taskStandaloneDialog").close();
  await loadData();
  showToast("Tarefa criada.");
}

async function createUser(event) {
  event.preventDefault();
  const message = $("createUserMessage");
  message.className = "form-message";
  const apelido = normalizeNickname($("newUserNickname").value);
  if (!isValidNickname(apelido)) {
    message.textContent = "O nome de usuário deve ter de 3 a 30 caracteres e usar apenas letras minúsculas, números, ponto, hífen ou _.";
    return;
  }
  message.textContent = "Criando usuário...";

  const { data, error } = await supabase.functions.invoke("admin-create-user", {
    body: {
      nome: $("newUserName").value.trim(),
      apelido: normalizeNickname($("newUserNickname").value),
      email: $("newUserEmail").value.trim(),
      password: $("newUserPassword").value,
      perfil: $("newUserRole").value,
    },
  });

  if (error || data?.error) {
    message.textContent = data?.error || error?.message || "Não foi possível criar. Confirme se a Edge Function foi publicada.";
    return;
  }

  message.className = "form-message success";
  message.textContent = "Usuário criado com sucesso.";
  event.target.reset();
  await loadData();
}

async function updateUserProfile(id, patch) {
  if (id === state.user.id && patch.ativo === false) return showToast("Você não pode desativar seu próprio usuário.", "error");
  const { error } = await supabase.from("profiles").update(patch).eq("id", id);
  if (error) return showToast(error.message, "error");
  await loadData();
  showToast("Usuário atualizado.");
}

function bindEvents() {
  $("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = $("loginMessage");
    message.textContent = "Entrando...";
    const identifier = $("loginEmail").value.trim();
    const password = $("loginPassword").value;
    let data;
    let error;

    if (identifier.includes("@")) {
      const result = await supabase.auth.signInWithPassword({ email: identifier, password });
      data = result.data;
      error = result.error;
    } else {
      const result = await supabase.functions.invoke("login-username", {
        body: { username: normalizeNickname(identifier), password },
      });

      if (result.error || result.data?.error) {
        error = result.error || new Error(result.data?.error);
      } else if (result.data?.session?.access_token && result.data?.session?.refresh_token) {
        const sessionResult = await supabase.auth.setSession({
          access_token: result.data.session.access_token,
          refresh_token: result.data.session.refresh_token,
        });
        data = sessionResult.data;
        error = sessionResult.error;
      } else {
        error = new Error("Sessão inválida.");
      }
    }

    if (error || !data?.user) {
      message.textContent = "Usuário/e-mail ou senha inválidos.";
      return;
    }

    message.textContent = "";
    await startAuthenticated(data.user);
  });

  $("logoutButton").addEventListener("click", () => supabase.auth.signOut());
  $("refreshButton").addEventListener("click", loadData);
  $("newClientButton").addEventListener("click", openNewClient);
  $("clientForm").addEventListener("submit", saveClient);
  $("deleteClientButton").addEventListener("click", deleteClient);
  $("historyForm").addEventListener("submit", saveHistory);
  $("ticketForm").addEventListener("submit", saveTicket);
  $("taskForm").addEventListener("submit", saveTask);
  $("createUserForm").addEventListener("submit", createUser);
  $("newProjectButton").addEventListener("click", () => {
    const drill = state.projectsDrill;
    let prefill = null;
    if (drill.municipio) {
      const source = state.projects.find((p) => municipioKeyOf(p) === drill.municipio);
      if (source) prefill = { cidade: source.cidade, estado: source.estado };
    }
    openProjectDialog(null, prefill);
  });
  $("projectForm").addEventListener("submit", saveProject);
  $("newProgressButton").addEventListener("click", () => openProgressDialog(state.progressDrill.projetoId || ""));
  $("progressForm").addEventListener("submit", saveProjectProgress);
  $("clientProject").addEventListener("change", applyProjectToClientForm);
  $("newMarketingProjectButton").addEventListener("click", openMarketingProjectDialog);
  $("marketingProjectForm").addEventListener("submit", saveMarketingProject);
  $("newTicketButton").addEventListener("click", openTicketDialog);
  $("ticketStandaloneForm").addEventListener("submit", saveStandaloneTicket);
  $("newTaskButton").addEventListener("click", openTaskDialog);
  $("taskStandaloneForm").addEventListener("submit", saveStandaloneTask);
  setupClientPicker("ticketStandalone");
  setupClientPicker("taskStandalone");

  $("editDetailClientButton").addEventListener("click", () => {
    const client = state.clients.find((item) => item.id === state.selectedClientId);
    $("clientDetailDialog").close();
    openEditClient(client);
  });

  document.querySelectorAll("[data-close-dialog]").forEach((button) => button.addEventListener("click", () => $(button.dataset.closeDialog).close()));
  document.querySelectorAll(".nav-button").forEach((button) => button.addEventListener("click", () => setView(button.dataset.view)));

  ["clientSearch", "municipalityFilter", "nucleusFilter", "clientStatusFilter", "clientOwnerFilter"].forEach((id) => $(id).addEventListener(id === "clientSearch" ? "input" : "change", renderClients));
  ["pipelineSearch", "pipelineOwnerFilter"].forEach((id) => $(id).addEventListener(id === "pipelineSearch" ? "input" : "change", renderPipeline));
  ["ticketSearch", "ticketMunicipalityFilter", "ticketNucleusFilter", "ticketSectorFilter", "ticketStatusFilter"].forEach((id) => $(id).addEventListener(id === "ticketSearch" ? "input" : "change", () => { state.ticketsVisible = LIST_PAGE_SIZE; renderTickets(); }));
  ["taskSearch", "taskMunicipalityFilter", "taskNucleusFilter", "taskStateFilter"].forEach((id) => $(id).addEventListener(id === "taskSearch" ? "input" : "change", () => { state.tasksVisible = LIST_PAGE_SIZE; renderTasks(); }));
  ["projectSearch", "projectStateFilter", "projectActiveFilter"].forEach((id) => $(id).addEventListener(id === "projectSearch" ? "input" : "change", renderProjects));
  ["progressSearch", "progressStateFilter", "progressStatusFilter", "progressActivityFilter"].forEach((id) => {
    $(id).addEventListener(id === "progressSearch" ? "input" : "change", renderProjectProgress);
  });
  ["marketingSearch", "marketingStatusFilter"].forEach((id) => $(id).addEventListener(id === "marketingSearch" ? "input" : "change", renderMarketingProjects));
  $("ticketsLoadMore").addEventListener("click", () => { state.ticketsVisible += LIST_PAGE_SIZE; renderTickets(); });
  $("tasksLoadMore").addEventListener("click", () => { state.tasksVisible += LIST_PAGE_SIZE; renderTasks(); });

  document.addEventListener("click", async (event) => {
    const openButton = event.target.closest("[data-open-client]");
    if (openButton) openClientDetail(openButton.dataset.openClient);

    const resolveButton = event.target.closest("[data-resolve-ticket]");
    if (resolveButton) resolveTicket(resolveButton.dataset.resolveTicket);

    const taskButton = event.target.closest("[data-toggle-task]");
    if (taskButton) toggleTask(taskButton.dataset.toggleTask);

    const editProjectButton = event.target.closest("[data-edit-project]");
    if (editProjectButton) openProjectDialog(projectById(editProjectButton.dataset.editProject));

    const openProjectProgressButton = event.target.closest("[data-open-project-progress]");
    if (openProjectProgressButton) {
      const project = projectById(openProjectProgressButton.dataset.openProjectProgress);
      if (project) {
        state.progressDrill.municipio = municipioKeyOf(project);
        state.progressDrill.projetoId = project.id;
      }
      setView("andamentos");
      renderProjectProgress();
    }

    const newProjectProgressButton = event.target.closest("[data-new-progress-project]");
    if (newProjectProgressButton) openProgressDialog(newProjectProgressButton.dataset.newProgressProject);

    const deleteProgressButton = event.target.closest("[data-delete-progress]");
    if (deleteProgressButton) {
      await deleteProjectProgress(
        deleteProgressButton.dataset.deleteProgress,
        deleteProgressButton.dataset.deleteProgressProject
      );
    }

    // Navegação em três níveis (Município → Projeto → Detalhes) — Projetos
    const projectsCrumb = event.target.closest("[data-projects-crumb]");
    if (projectsCrumb) {
      const action = projectsCrumb.dataset.projectsCrumb;
      if (action === "root") { state.projectsDrill.municipio = null; state.projectsDrill.projetoId = null; }
      else if (action.startsWith("municipio:")) { state.projectsDrill.municipio = action.slice("municipio:".length); state.projectsDrill.projetoId = null; }
      renderProjects();
    }

    const selectMunicipio = event.target.closest("[data-select-municipio]");
    if (selectMunicipio) {
      state.projectsDrill.municipio = selectMunicipio.dataset.selectMunicipio;
      state.projectsDrill.projetoId = null;
      renderProjects();
    }

    const selectProject = event.target.closest("[data-select-project]");
    if (selectProject) {
      state.projectsDrill.projetoId = selectProject.dataset.selectProject;
      renderProjects();
    }

    // Navegação em três níveis (Município → Projeto → Andamentos) — Andamentos
    const progressCrumb = event.target.closest("[data-progress-crumb]");
    if (progressCrumb) {
      const action = progressCrumb.dataset.progressCrumb;
      if (action === "root") { state.progressDrill.municipio = null; state.progressDrill.projetoId = null; }
      else if (action.startsWith("municipio:")) { state.progressDrill.municipio = action.slice("municipio:".length); state.progressDrill.projetoId = null; }
      renderProjectProgress();
    }

    const selectProgressMunicipio = event.target.closest("[data-select-progress-municipio]");
    if (selectProgressMunicipio) {
      state.progressDrill.municipio = selectProgressMunicipio.dataset.selectProgressMunicipio;
      state.progressDrill.projetoId = null;
      renderProjectProgress();
    }

    const selectProgressProject = event.target.closest("[data-select-progress-project]");
    if (selectProgressProject) {
      state.progressDrill.projetoId = selectProgressProject.dataset.selectProgressProject;
      renderProjectProgress();
    }

    const marketingProjectButton = event.target.closest("[data-open-marketing-project]");
    if (marketingProjectButton) openMarketingJourney(marketingProjectButton.dataset.openMarketingProject);

    const marketingEtapaButton = event.target.closest("[data-toggle-marketing-etapa]");
    if (marketingEtapaButton && marketingEtapaButton.dataset.toggleMarketingEtapa) toggleMarketingEtapa(marketingEtapaButton.dataset.toggleMarketingEtapa);
  });

  document.addEventListener("change", (event) => {
    const nicknameInput = event.target.closest("[data-user-nickname]");
    if (nicknameInput) {
      const apelido = normalizeNickname(nicknameInput.value);
      if (!isValidNickname(apelido)) {
        showToast("Nome de usuário inválido. Use 3 a 30 caracteres: letras, números, ponto, hífen ou _.", "error");
        renderUsers();
      } else {
        updateUserProfile(nicknameInput.dataset.userNickname, { apelido });
      }
    }

    const roleSelect = event.target.closest("[data-user-role]");
    if (roleSelect) updateUserProfile(roleSelect.dataset.userRole, { perfil: roleSelect.value });

    const activeSelect = event.target.closest("[data-user-active]");
    if (activeSelect) updateUserProfile(activeSelect.dataset.userActive, { ativo: activeSelect.value === "true" });
  });
}

bootstrap().catch((error) => {
  console.error(error);
  showOnly("loginScreen");
  $("loginMessage").textContent = `Erro ao iniciar: ${error.message}`;
});
